const firebaseConfig = {
  apiKey: "AIzaSyARqj0_tnZoO5YDAVPxQeMh5KhhECo8J38",
  authDomain: "virtual-esp32-monitor-2dbca.firebaseapp.com",
  databaseURL: "https://virtual-esp32-monitor-2dbca-default-rtdb.asia-southeast1.firebasedatabase.app",
  projectId: "virtual-esp32-monitor-2dbca",
  storageBucket: "virtual-esp32-monitor-2dbca.firebasestorage.app",
  messagingSenderId: "1083228962718",
  appId: "1:1083228962718:web:6254e39342964b9fd0208f"
};

firebase.initializeApp(firebaseConfig);
const db = firebase.database();