const tempEl = document.getElementById("temp");
const humEl = document.getElementById("humidity");
const uvEl = document.getElementById("uv");
const lightEl = document.getElementById("light");
const alertEl = document.getElementById("alert");

// Hourly buffer to store readings in memory
let hourlyBuffer = { temperature: [], humidity: [], uv: [], light: [] };
let currentHour = new Date().getHours();

// Helpers
function getHourKey(date = new Date()) {
  const y = date.getFullYear();
  const m = (date.getMonth()+1).toString().padStart(2,'0');
  const d = date.getDate().toString().padStart(2,'0');
  const h = date.getHours().toString().padStart(2,'0');
  return `${y}-${m}-${d}-${h}`;
}

function getDateKey(date = new Date()) {
  const y = date.getFullYear();
  const m = (date.getMonth()+1).toString().padStart(2,'0');
  const d = date.getDate().toString().padStart(2,'0');
  return `${y}-${m}-${d}`;
}

// Update daily summary
function updateDailySummary(param, latestHourAvg) {
  const dateKey = getDateKey();
  const dailyRef = db.ref(`daily_summary/${dateKey}/${param}_hourly`);
  
  dailyRef.push(latestHourAvg);

  dailyRef.once("value", snap => {
    const vals = snap.val() ? Object.values(snap.val()) : [];
    const dailyAvg = vals.reduce((a,b)=>a+b,0)/vals.length;
    db.ref(`daily_summary/${dateKey}`).update({ [`avg_${param}`]: parseFloat(dailyAvg.toFixed(2)) });
  });
}

// Process and finalize previous hour
function processHourlyData() {
  const previousHourKey = getHourKey(new Date(new Date().setHours(currentHour)));
  const hourData = {};

  ["temperature","humidity","uv","light"].forEach(param => {
    const arr = hourlyBuffer[param];
    const avg = arr.length > 0 ? arr.reduce((a,b)=>a+b,0)/arr.length : 0;
    hourData[`avg_${param}`] = parseFloat(avg.toFixed(2));
    updateDailySummary(param, avg);
  });

  db.ref(`sensor_history/${previousHourKey}`).set(hourData);

  // Reset buffer
  hourlyBuffer = { temperature: [], humidity: [], uv: [], light: [] };
}

// Main interval
setInterval(() => {
  const temp = parseFloat((20 + Math.random() * 10).toFixed(1));
  const hum = parseFloat((50 + Math.random() * 30).toFixed(1));
  const uv = parseFloat((0 + Math.random() * 11).toFixed(1));
  const light = parseFloat((100 + Math.random() * 900).toFixed(1));

  // Live readings
  db.ref("sensor").set({ temperature: temp, humidity: hum, uv: uv, light: light });

  // Add readings to buffer
  hourlyBuffer.temperature.push(temp);
  hourlyBuffer.humidity.push(hum);
  hourlyBuffer.uv.push(uv);
  hourlyBuffer.light.push(light);

  const nowHour = new Date().getHours();

  // Update running hourly average for the current hour
  const currentHourKey = getHourKey();
  const avgData = {};
  ["temperature","humidity","uv","light"].forEach(param => {
    const arr = hourlyBuffer[param];
    const avg = arr.length > 0 ? arr.reduce((a,b)=>a+b,0)/arr.length : 0;
    avgData[`avg_${param}`] = parseFloat(avg.toFixed(2));
  });
  db.ref(`sensor_history/${currentHourKey}`).set(avgData);

  // Finalize previous hour if hour changed
  if(nowHour !== currentHour){
    processHourlyData();
    currentHour = nowHour;
  }

  // Update webpage
  tempEl.textContent = temp;
  humEl.textContent = hum;
  uvEl.textContent = uv;
  lightEl.textContent = light;

  // Alerts
  let alerts = [];
  if(temp >= 30) alerts.push("High Temperature!");
  if(hum >= 75) alerts.push("High Humidity!");
  if(uv >= 8) alerts.push("High UV!");
  if(light >= 800) alerts.push("Bright Light!");
  alertEl.textContent = alerts.length > 0 ? alerts.join(" | ") : "No alerts";

}, 10000);